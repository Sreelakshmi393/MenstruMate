from django.shortcuts import render
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage

#from django.conf import settings

#from.forms import *


# Create your views here.
def index(request):
    return render(request,'index.html')

        # Process the form data as needed
        # For example, you can save the values to a database or perform calculations

        